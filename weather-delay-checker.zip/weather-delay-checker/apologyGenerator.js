// apologyGenerator.js - Weather-Aware Apology function
function generateWeatherAwareApology(customer, city, condition) {
  let message = `Hi ${customer}, `;
  
  if (condition === 'Rain') {
    message += `your order to ${city} is delayed due to heavy rain. We appreciate your patience!`;
  } else if (condition === 'Snow') {
    message += `your order to ${city} is delayed because of snowy conditions. Stay safe and thanks for understanding!`;
  } else if (condition === 'Extreme') {
    message += `your order to ${city} is delayed due to extreme weather. We're working hard to get it to you soon.`;
  } else {
    message += `your order to ${city} is delayed due to ${condition.toLowerCase()} weather. Sorry for the inconvenience!`;
  }
  
  return message;
}

module.exports = { generateWeatherAwareApology };
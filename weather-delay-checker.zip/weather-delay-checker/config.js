// config.js - Handles environment variables safely
const dotenv = require('dotenv');

const result = dotenv.config({ 
  path: './.env',
  debug: true 
});

console.log(' Config loaded. API Key present?', !!process.env.OPENWEATHER_API_KEY);

if (!process.env.OPENWEATHER_API_KEY) {
  console.error(' ERROR: API key not loaded. Check .env file location and name.');
  process.exit(1);
}

module.exports = {
  OPENWEATHER_API_KEY: process.env.OPENWEATHER_API_KEY
};
// index.js - Main entry point
console.log('  Weather Delivery Delay Checker (Modular Version)\n');

const { processAllOrders } = require('./orderProcessor');

processAllOrders()
  .catch(err => {
    console.error('  Unexpected error:', err.message);
  });
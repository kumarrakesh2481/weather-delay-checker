// orderProcessor.js - Core business logic for orders
const fs = require('fs');
const { fetchAllWeather } = require('./weatherService');
const { generateWeatherAwareApology } = require('./apologyGenerator');

async function processAllOrders() {
  let orders = JSON.parse(fs.readFileSync('orders.json', 'utf8'));

  const results = await fetchAllWeather(orders);

  results.forEach(({ order, weather }) => {
    if (!weather) return; 

    const condition = weather.main;
    if (['Rain', 'Snow', 'Extreme'].includes(condition)) {
      order.status = 'Delayed';
      order.apology_message = generateWeatherAwareApology(
        order.customer,
        order.city,
        condition
      );
      console.log(`    Order ${order.order_id} marked as DELAYED (${condition})`);
    }
  });

  // Save updated JSON
  fs.writeFileSync('orders.json', JSON.stringify(orders, null, 2));
  console.log('\n All orders processed! Check orders.json for updates.');
}

module.exports = { processAllOrders };
// test-key.js  ← Run this to check only your API key
require('dotenv').config();

const axios = require('axios');

async function testKey() {
  console.log(' Testing your OpenWeatherMap key...');
  console.log('Key loaded:', process.env.OPENWEATHER_API_KEY ? 'YES' : 'NO');

  try {
    const res = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
      params: {
        q: 'London',
        appid: process.env.OPENWEATHER_API_KEY,
        units: 'metric'
      }
    });
    console.log(' KEY IS WORKING!');
    console.log('Weather in London:', res.data.weather[0].main, res.data.main.temp + '°C');
  } catch (err) {
    console.log(' KEY NOT WORKING YET');
    console.log('Error:', err.response?.data || err.message);
  }
}

testKey();
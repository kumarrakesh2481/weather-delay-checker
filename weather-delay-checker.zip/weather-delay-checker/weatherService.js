// weatherService.js - Responsible for fetching weather in parallel
const axios = require('axios');
const config = require('./config');

async function getWeather(city) {
  try {
    const response = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
      params: {
        q: city,
        appid: config.OPENWEATHER_API_KEY,
        units: 'metric'
      }
    });
    return response.data.weather[0];
  } catch (error) {
    const status = error.response?.status;
    if (status === 404) {
      console.error(` City not found: "${city}"`);
    } else if (status === 401) {
      console.error(` API key error for "${city}" - run test-key.js`);
    } else {
      console.error(` Weather fetch error for ${city}: ${error.message}`);
    }
    throw error;
  }
}

// This is the parallel part - called from orderProcessor
async function fetchAllWeather(orders) {
  console.log(' Starting parallel weather fetch for all cities...\n');
  
  const promises = orders.map(async (order) => {
    if (order.status !== 'Pending') return order;
    
    console.log(` Checking Order ${order.order_id} → ${order.city}`);
    try {
      const weather = await getWeather(order.city);
      console.log(`    Weather in ${order.city}: ${weather.main}`);
      return { order, weather };
    } catch (e) {
      console.log(`    Skipped ${order.city} (error handled)\n`);
      return { order, weather: null };
    }
  });

  return Promise.all(promises);   // ← This is the required concurrent part
}

module.exports = { fetchAllWeather };